#!/usr/bin/env python
# -*- coding: utf-8 -*-

misp_url = 'https://localhost'
misp_key = 'pfsoob9mktcqSsvb6McHW12Lu8RUA4qvvhhX1Z7t' # The MISP auth key can be found on the MISP web interface under the automation section
misp_verifycert = False
