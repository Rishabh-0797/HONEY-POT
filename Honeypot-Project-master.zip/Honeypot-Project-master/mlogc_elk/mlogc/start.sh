#!/bin/bash
httpd
bin/logstash -f /usr/share/logstash/logstash.conf 
