# ~/bin/sh
httpd
/usr/share/logstash/bin/logstash -f /usr/share/logstash/logstash.conf
