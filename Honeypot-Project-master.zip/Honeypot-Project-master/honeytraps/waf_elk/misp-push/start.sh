#!/bin/bash
pipenv install
pipenv run python3 /app/misp-push.py