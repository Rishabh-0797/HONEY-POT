cd /etc/logstash/conf.d/
/opt/logstash/bin/logstash -f filebeat_logstash.conf
